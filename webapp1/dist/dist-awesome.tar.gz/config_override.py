#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# config_override.py作为生产环境的标准配置

configs = {
    'db': {
        'host': '127.0.0.1'
        }
    }
